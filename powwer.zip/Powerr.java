package net.mcreator.mijnmod.customcode;

import net.minecraft.world.World;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.Hand;
import net.minecraft.util.ActionResultType;
import net.minecraft.block.Blocks;

public class Powerr {
    
    public static void placeStoneUnderPlayer(PlayerEntity player) {
        // Verkrijg de wereld van de speler
        World world = player.world;
        
        // Verkrijg de huidige positie van de speler
        BlockPos playerPos = player.getPosition();

        // Bepaal de positie onder de speler
        BlockPos stonePos = playerPos.down();

        // Controleer of de blokpositie vrij is
        if (world.isAirBlock(stonePos)) {
            // Plaats een steen blok onder de speler
            world.setBlockState(stonePos, Blocks.STONE.getDefaultState());
        }
    }
}
